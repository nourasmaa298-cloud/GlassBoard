# Glass Keyboard — GitHub Actions package

1. فك ضغط `GlassKeyboard-GitHub.zip` على جهازك.
2. ارفع الملف `GlassKeyboard.zip` ومجلد `.github` إلى جذر مستودع GitHub (لا ترفع ملف الحزمة الخارجية فقط).
3. افتح Actions في GitHub وشغّل `Build APK` أو ادفع commit جديدًا.
4. بعد انتهاء البناء، افتح تشغيل الـ workflow ونزّل artifact باسم `GlassKeyboard-APK`.

بعد تثبيت APK: افتح التطبيق، فعّل لوحة المفاتيح من إعدادات النظام، ثم اختر Glass Keyboard.

هذه نسخة أولية. دعم Blur يعتمد على Android 12+، وميزات مثل الاقتراحات والتصحيح التلقائي والتخطيط العربي الكامل غير مضافة بعد.
